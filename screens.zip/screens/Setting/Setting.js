import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Modal,
  Image,
  ImageBackground,
  TouchableOpacity,
  TextInput,
  StatusBar,
  ScrollView,
  SafeAreaView,
  Switch,
  Platform,
} from "react-native";
import React, { useState } from "react";
import { IMAGEPATH } from "../../Icon/Icon";

import LinearGradient from "react-native-linear-gradient";
const { height, width } = Dimensions.get("window");

import { ProgressBar, MD3Colors } from "react-native-paper";
import { LinearTextGradient } from "react-native-text-gradient";
//import ToggleSwitch from "toggle-switch-react-native";

import AppButton from "../../components/CustomButton/CustomButton";
import AppButtonCircle from "../../components/coustomCircleButton/CustomCircleButton";
import AppCircleButtonRed from "../../components/coustomCircleButton/coustomCircleButtonRed";

//import { types } from "@babel/core";

const Setting = (props) => {
  const [on, seton] = useState(true);
  const [isEnabled, setIsEnabled] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const toggleSwitch = () => setIsEnabled((previousState) => !previousState);
  const onoff = () => {
    if (on == true) {
      seton(false);
    } else {
      seton(true);
    }
  };
  return (
    <SafeAreaView>
      <ScrollView>
        <View style={styles.mainContainer}>
          <ImageBackground
            style={styles.ImageBackground}
            source={IMAGEPATH.SPLASH_BACKGROUND}
          >
            <Modal
              animationType="slide"
              transparent={true}
              visible={modalVisible}
              onRequestClose={() => {
                Alert.alert("Modal has been closed.");
                setModalVisible(!modalVisible);
              }}
            >
              <View
                style={{
                  flex: 1,
                  justifyContent: "center",
                  //  backgroundColor: "blue",
                  marginTop:
                    Platform.OS === "android" ? height * 0.06 : height * 0.12,
                }}
              >
                <LinearGradient
                  colors={[
                    "rgba(255, 255, 255, 0.2)",
                    "rgba(255, 255, 254, 0)",
                  ]}
                  style={{
                    flex: 1,
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <TouchableOpacity onPress={() => setModalVisible(false)}>
                    <View
                      style={{
                        height: height * 0.0,
                        width: width * 0.9,
                        alignSelf: "center",
                        justifyContent: "center",
                        //  backgroundColor: "blue",
                      }}
                    ></View>
                  </TouchableOpacity>

                  <View
                    style={{
                      height: height * 0.42,
                      width: width * 0.98,
                      alignSelf: "center",
                      // backgroundColor: "red",
                      alignItems: "center",
                    }}
                  >
                    <View
                      style={{
                        borderWidth: 1.5,
                        borderBottomColor: "rgb(161,239,188)",
                        borderLeftColor: "rgb(121,211,204)",
                        borderRightColor: "rgb(121,211,204)",
                        borderTopColor: "rgb(184,138,194)",
                        borderRadius: 16,
                      }}
                    >
                      <LinearGradient
                        colors={[
                          "rgba(255, 255, 255, 0.2)",
                          "rgba(255, 255, 270, 0.1)",
                          " rgba(0, 0, 0, 0.25)",
                        ]}
                        style={{
                          height: height * 0.23,
                          width: width * 0.92,
                          backgroundColor: "rgb(86,121,91)",
                          borderRadius: 16,
                          shadowColor: "#0000000",
                          shadowOffset: { width: 0.2, height: 2 },
                          shadowOpacity: 0.1,
                          shadowRadius: 15,
                          elevation: 2,
                        }}
                      >
                        <View
                          style={{
                            height: height * 0.065,
                            width: width * 0.75,
                            //  backgroundColor: "blue",
                            alignSelf: "center",
                            alignItems: "center",
                            justifyContent: "center",
                          }}
                        >
                          <Text
                            style={{
                              fontSize: width * 0.075,
                              color: "#FFFFFF",
                              //  textAlign: "center",
                              fontFamily: "SairaSemiCondensed-regular",
                            }}
                          >
                            Logout
                          </Text>
                        </View>
                        <View
                          style={{
                            height: height * 0.05,
                            width: width * 0.85,
                            //backgroundColor: "blue",
                            alignSelf: "center",
                            alignItems: "center",
                            justifyContent: "center",
                          }}
                        >
                          <Text
                            style={{
                              fontSize: width * 0.04,
                              color: "#FFFFFF",
                              //  textAlign: "center",
                              fontFamily: "sen-regular",
                            }}
                          >
                            Are you sure you want to logout?
                          </Text>
                        </View>
                        <View
                          style={{
                            height: height * 0.078,
                            width: width * 0.55,
                            // marginLeft: width * 0.08,
                            alignSelf: "center",
                            // backgroundColor: "blue",
                            flexDirection: "row",
                            alignItems: "flex-end",
                            justifyContent: "space-between",
                          }}
                        >
                          <TouchableOpacity
                            onPress={() => setModalVisible(false)}
                          >
                            <View
                              style={{
                                borderWidth: 2,
                                borderBottomColor: "rgb(161,239,188)",
                                borderLeftColor: "rgb(121,211,204)",
                                borderRightColor: "rgb(121,211,204)",
                                borderTopColor: "rgb(184,138,194)",
                                borderRadius: 35,
                                height: height * 0.05,
                                width: width * 0.25,
                                justifyContent: "center",
                                alignItems: "center",
                              }}
                            >
                              <Text style={styles.saveTextstyle}>Cancel</Text>
                            </View>
                          </TouchableOpacity>
                          <TouchableOpacity>
                            <View
                              style={{
                                borderWidth: 2,
                                borderBottomColor: "rgb(161,239,188)",
                                borderLeftColor: "rgb(121,211,204)",
                                borderRightColor: "rgb(121,211,204)",
                                borderTopColor: "rgb(184,138,194)",
                                borderRadius: 35,
                                height: height * 0.05,
                                width: width * 0.25,
                                justifyContent: "center",
                                alignItems: "center",
                              }}
                            >
                              <Text style={styles.saveTextstyle}>Confirm</Text>
                            </View>
                          </TouchableOpacity>
                        </View>
                      </LinearGradient>
                    </View>
                  </View>
                </LinearGradient>
              </View>
            </Modal>
            <View style={styles.headingView}>
              <View style={styles.backView}>
                <TouchableOpacity
                  onPress={() => props.navigation.navigate("Home")}
                >
                  <Image
                    style={styles.backImage}
                    source={IMAGEPATH.BACK_ICON}
                  />
                </TouchableOpacity>
              </View>
              <View
                style={{
                  height: height * 0.06,
                  width: width * 0.45,
                  //  backgroundColor: "green",
                  marginLeft: width * 0.15,
                  justifyContent: "center",
                }}
              >
                <Text style={styles.HeadingTextStyle}>Settings</Text>
              </View>
            </View>
            <View style={styles.ProfilemainView}>
              <View style={styles.ProfileBorderView}>
                <LinearGradient
                  colors={[
                    "rgba(255, 255, 255, 0.2)",
                    "rgba(255, 255, 270, 0.1)",
                  ]}
                  style={styles.ProfileBorderView}
                >
                  <View
                    style={{
                      alignItems: "center",
                      height: height * 0.19,
                      width: width * 0.43,
                      flexDirection: "row",
                      //  backgroundColor: "red",
                      justifyContent: "center",
                      //borderRadius: 95,
                    }}
                  >
                    <View>
                      <Image
                        style={{
                          height: height * 0.19,
                          width: width * 0.38,
                          resizeMode: "contain",
                        }}
                        source={IMAGEPATH.PROFILE_Icon}
                      />
                    </View>
                    <TouchableOpacity
                      style={{
                        height: width * 0.13,
                        width: width * 0.13,

                        borderRadius:
                          Math.round(
                            Dimensions.get("window").width +
                              Dimensions.get("window").height
                          ) / 2,
                        backgroundColor: "#3BD0C7",
                        position: "absolute",
                        bottom: height * 0.022,
                        left: width * 0.27,
                        justifyContent: "center",
                        alignItems: "center",
                        // alignSelf: "flex-end",
                      }}
                    >
                      <View
                        style={{
                          height: height * 0.06,
                          width: width * 0.13,

                          borderRadius: 95,
                          //   backgroundColor: "#3BD0C7",
                          // position: "absolute",
                          //   bottom: height * 0.019,
                          //   left: width * 0.27,
                          justifyContent: "center",
                          alignItems: "center",
                          // alignSelf: "flex-end",
                        }}
                      >
                        <Image
                          style={{
                            height: height * 0.02,
                            width: width * 0.06,
                          }}
                          source={IMAGEPATH.Camera_Icon}
                        />
                      </View>
                    </TouchableOpacity>
                  </View>
                </LinearGradient>
              </View>
            </View>
            <View style={styles.EmailVIew}>
              <Text style={styles.NameText}>Umair Siddiqui</Text>
              <Text style={styles.emailText}>de-umair@mobiloitte.com</Text>
            </View>
            <LinearGradient
              colors={[
                "rgba(255, 255, 255, 0.2)",
                "rgba(255, 255, 255, 0)",
                "rgba(0, 0, 0, 0.25)",
              ]}
              style={styles.SettingView}
            >
              <View style={styles.AcountHeading}>
                <View style={styles.AccountProfileView}>
                  <Image
                    style={{
                      height: height * 0.022,
                      width: width * 0.042,
                      resizeMode: "contain",
                    }}
                    source={IMAGEPATH.Account_Profile}
                  />
                </View>
                <View style={styles.AccountProfileView1}>
                  <Image
                    style={{
                      height: height * 0.09,
                      width: width * 0.18,
                      resizeMode: "contain",
                    }}
                    source={IMAGEPATH.Account_Text}
                  />
                </View>
              </View>
              <View style={styles.editmainView}>
                <TouchableOpacity
                  onPress={() => props.navigation.navigate("EditProfile")}
                >
                  <LinearGradient
                    colors={[
                      "rgba(255, 255, 255, 0.2)",
                      "rgba(255, 255, 255, 0)",
                    ]}
                    style={styles.editView}
                  >
                    <View
                      style={{
                        height: height * 0.06,
                        width: width * 0.75,
                        flexDirection: "row",
                        //  backgroundColor: "blue",
                        alignSelf: "center",
                        alignItems: "center",
                        justifyContent: "space-between",
                      }}
                    >
                      <Text style={styles.editText}>Edit account </Text>
                      <Image
                        style={{
                          height: height * 0.02,
                          width: width * 0.04,
                          resizeMode: "contain",
                        }}
                        source={IMAGEPATH.Forword_Icon}
                      />
                    </View>
                  </LinearGradient>
                </TouchableOpacity>

                {/* secondGredient */}
                <TouchableOpacity>
                  <LinearGradient
                    colors={[
                      "rgba(255, 255, 255, 0.2)",
                      "rgba(255, 255, 255, 0)",
                    ]}
                    style={styles.editView}
                  >
                    <View
                      style={{
                        height: height * 0.06,
                        width: width * 0.75,
                        flexDirection: "row",
                        //  backgroundColor: "blue",
                        alignSelf: "center",
                        alignItems: "center",
                        justifyContent: "space-between",
                      }}
                    >
                      <Text style={styles.editText}>Change password </Text>
                      <Image
                        style={{
                          height: height * 0.02,
                          width: width * 0.04,
                          resizeMode: "contain",
                        }}
                        source={IMAGEPATH.Forword_Icon}
                      />
                    </View>
                  </LinearGradient>
                </TouchableOpacity>

                {/* Third Gredient */}

                <TouchableOpacity>
                  <LinearGradient
                    colors={[
                      "rgba(255, 255, 255, 0.2)",
                      "rgba(255, 255, 255, 0)",
                    ]}
                    style={styles.editView}
                  >
                    <View
                      style={{
                        height: height * 0.06,
                        width: width * 0.75,
                        flexDirection: "row",
                        //  backgroundColor: "blue",
                        alignSelf: "center",
                        alignItems: "center",
                        justifyContent: "space-between",
                      }}
                    >
                      <Text style={styles.editText}>Sport log </Text>
                      <Image
                        style={{
                          height: height * 0.02,
                          width: width * 0.04,
                          resizeMode: "contain",
                        }}
                        source={IMAGEPATH.Forword_Icon}
                      />
                    </View>
                  </LinearGradient>
                </TouchableOpacity>
              </View>

              <View style={styles.AcountHeading2}>
                <View style={styles.AccountProfileView}>
                  <Image
                    style={{
                      height: height * 0.03,
                      width: width * 0.06,
                      resizeMode: "contain",
                    }}
                    source={IMAGEPATH.BELL_Icon}
                  />
                </View>
                <View style={styles.AccountProfileView1}>
                  <Image
                    style={{
                      height: height * 0.12,
                      width: width * 0.24,
                      resizeMode: "contain",
                    }}
                    source={IMAGEPATH.Notification}
                  />
                </View>
              </View>
              <View style={styles.lastheading}>
                <View
                  style={{
                    height: height * 0.04,
                    width: width * 0.3,
                    // flexDirection: "row",
                    //backgroundColor: "red",
                    alignSelf: "center",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Text style={styles.editText}>Sound </Text>
                </View>
                <View
                  style={{
                    height: height * 0.04,
                    width: width * 0.2,
                    //backgroundColor: "red",
                    alignSelf: "center",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <TouchableOpacity onPress={() => onoff()}>
                    {on !== true ? (
                      <Image
                        style={{
                          height: height * 0.07,
                          width: width * 0.14,
                          resizeMode: "contain",
                          transform: [{ rotate: "180deg" }],
                        }}
                        source={IMAGEPATH.Toggle_Icon}
                      />
                    ) : (
                      <Image
                        source={IMAGEPATH.Toggle_Icon}
                        style={{
                          height: height * 0.07,
                          width: width * 0.14,
                          resizeMode: "contain",
                          // transform: [{ rotate: "180deg" }],
                        }}
                      />
                    )}
                  </TouchableOpacity>
                </View>
              </View>
              <View style={styles.logoutView}>
                <TouchableOpacity
                  onPress={() => setModalVisible(true)}
                  style={styles.logoutBUtton}
                >
                  <Text style={styles.logoutext}>LOGOUT</Text>
                </TouchableOpacity>
              </View>
            </LinearGradient>
          </ImageBackground>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default Setting;

const styles = StyleSheet.create({
  saveTextstyle: {
    fontSize: width * 0.035,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "sen-regular",
  },
  logoutext: {
    fontSize: width * 0.035,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "Sen-Bold",
  },
  logoutBUtton: {
    height: height * 0.04,
    width: width * 0.25,
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 35,
    backgroundColor: "#D03B3B",
  },
  logoutView: {
    height: height * 0.05,
    width: width * 0.35,
    alignSelf: "center",
    // backgroundColor: "blue",
  },
  lastheading: {
    height: height * 0.05,
    width: width * 0.89,
    alignSelf: "center",
    flexDirection: "row",
    // backgroundColor: "blue",
    justifyContent: "space-between",
  },
  editText: {
    fontSize: width * 0.045,
    color: "#FFFFFF",
    //  textAlign: "center",
    fontFamily: "Sen-regular",
  },
  editmainView: {
    height: Platform.OS === "android" ? height * 0.32 : height * 0.27,
    width: width * 0.89,
    alignSelf: "center",
    // backgroundColor: "blue",
    justifyContent: "space-evenly",
  },
  editView: {
    height: height * 0.07,
    width: width * 0.85,
    alignSelf: "center",
    //  backgroundColor: "green",
    justifyContent: "center",
    borderRadius: 45,
    //  marginTop: height * 0.02,

    // alignItems: "center",
  },
  AccountProfileView1: {
    height: height * 0.05,
    width: width * 0.39,
    alignSelf: "center",
    //  backgroundColor: "green",
    justifyContent: "center",
    // alignItems: "center",
  },
  AccountProfileView: {
    height: height * 0.05,
    width: width * 0.15,
    alignSelf: "center",
    marginLeft: width * 0.02,
    // backgroundColor: "green",
    justifyContent: "center",
    alignItems: "center",
  },
  AcountHeading2: {
    height: height * 0.06,
    width: width * 0.7,
    //backgroundColor: "blue",
    flexDirection: "row",
    //  marginTop: height * 0.03,
  },
  AcountHeading: {
    height: height * 0.06,
    width: width * 0.7,
    // backgroundColor: "blue",
    flexDirection: "row",
    marginTop: height * 0.03,
  },
  SettingView: {
    height: Platform.OS === "android" ? height * 0.7 : height * 0.68,
    width: width * 0.99,
    alignSelf: "center",
    borderTopRightRadius: 40,
    borderTopLeftRadius: 40,
    marginTop: height * 0.01,
    shadowColor: "#0000000",
    shadowOffset: { width: 0.2, height: 2 },
    shadowOpacity: Platform.OS === "android" ? 0 : 0.1,
    shadowRadius: Platform.OS === "android" ? 0 : 15,
    elevation: Platform.OS === "android" ? 0 : 2,
    // backgroundColor: "blue",
    // backdropFilter: "blur",
  },
  emailText: {
    fontSize: width * 0.038,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "Sen-regular",
  },
  NameText: {
    fontSize: width * 0.055,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-Bold",
  },
  EmailVIew: {
    height: height * 0.08,
    width: width * 0.9,
    alignSelf: "center",
    // backgroundColor: "blue",
  },
  ProfileBorderView: {
    height: width * 0.42,
    width: width * 0.42,
    alignSelf: "center",
    borderRadius:
      Math.round(
        Dimensions.get("window").width + Dimensions.get("window").height
      ) / 2,
    borderWidth: 1,
    borderLeftColor: "rgb(140,186,203)",
    borderRightColor: "rgb(140,186,203)",
    borderBottomColor: "rgb(183,255,178)",
    borderTopColor: "rgb(203,117,191)",
    // flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    //  backgroundColor: "green",
    //justifyContent: "space-around",
  },
  ProfilemainView: {
    height: height * 0.22,
    width: width * 0.55,
    alignSelf: "center",
    justifyContent: "center",
    // flexDirection: "row",
    alignItems: "center",
    //  backgroundColor: "blue",
    //justifyContent: "space-around",
  },
  HeadingTextStyle: {
    fontSize: width * 0.065,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-Bold",
  },
  backView: {
    height: height * 0.04,
    width: width * 0.11,
    // borderColor: "white",
    alignItems: "center",
    justifyContent: "center",
    // fbackgroundColor: "green",
  },
  headingView: {
    // backgroundColor: "blue",
    height: height * 0.08,
    width: width * 0.95,
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    //justifyContent: "space-around",
  },
  mainContainer: {
    height: height,
    width: width,
    // justifyContent:'center'
  },
  ImageBackground: {
    height: height,
    width: width,
    resizeMode: "contain",
    //justifyContent:'center'
  },
});
