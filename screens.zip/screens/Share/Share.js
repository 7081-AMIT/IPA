import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Modal,
  Image,
  ImageBackground,
  TouchableOpacity,
  TextInput,
  StatusBar,
  ScrollView,
  SafeAreaView,
} from "react-native";
import React, { useState } from "react";
import { IMAGEPATH } from "../../Icon/Icon";

import LinearGradient from "react-native-linear-gradient";
const { height, width } = Dimensions.get("window");

import { ProgressBar, MD3Colors } from "react-native-paper";
import { LinearTextGradient } from "react-native-text-gradient";

import AppButton from "../../components/CustomButton/CustomButton";
import AppButtonCircle from "../../components/coustomCircleButton/CustomCircleButton";
import AppCircleButtonRed from "../../components/coustomCircleButton/coustomCircleButtonRed";

const Share = (props) => {
  return (
    <SafeAreaView>
      <ScrollView>
        <View style={styles.mainContainer}>
          <ImageBackground
            style={styles.ImageBackground}
            source={IMAGEPATH.SPLASH_BACKGROUND}
          >
            <View
              style={{
                height: height * 0.5,
                width: width * 0.85,
                // borderColor: "white",
                alignItems: "center",
                justifyContent: "center",
                // backgroundColor: "blue",
                alignSelf: "center",
                // borderWidth: 1,
              }}
            >
              <Image
                style={styles.humanImageStyle}
                source={IMAGEPATH.MALE_ICON}
              />
            </View>

            <View style={styles.headingView1}>
              <View style={styles.walkingmainVIe}>
                <View style={styles.stpesIco}>
                  <View
                    style={{
                      // backgroundColor: "pink",
                      height: height * 0.06,
                      width: width * 0.08,
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <Image
                      style={{
                        height: height * 0.03,
                        width: width * 0.06,
                        resizeMode: "contain",
                        top: height * 0.002,
                      }}
                      source={IMAGEPATH.Steps_Icon}
                    />
                  </View>
                  <View
                    style={{
                      // backgroundColor: "pink",
                      height: height * 0.05,
                      // width: width * 0.25,
                      //justifyContent: "center",
                    }}
                  >
                    <Text
                      style={{
                        fontSize: width * 0.075,
                        color: "#FFFFFF",
                        //  textAlign: "center",
                        fontFamily: "SairaSemiCondensed-bold",
                      }}
                    >
                      205
                    </Text>
                  </View>
                  <View
                    style={{
                      height: height * 0.045,
                      width: width * 0.1,
                      // backgroundColor: "blue",
                      justifyContent: "flex-end",
                    }}
                  >
                    <Text style={styles.walkingTextStyle}>step</Text>
                  </View>
                </View>
              </View>

              <View
                style={{
                  height: height * 0.08,
                  width: width * 0.32,
                  //  backgroundColor: "blue",
                  // alignItems: "center",
                  flexDirection: "row",
                  // justifyContent: "center",
                  alignSelf: "center",
                }}
              >
                <View
                  style={{
                    height: height * 0.05,
                    width: width * 0.1,

                    // backgroundColor: "blue",
                    justifyContent: "flex-end",
                  }}
                >
                  <Text style={styles.walkingTextStyle}>Time</Text>
                </View>
                <View
                  style={{
                    height: height * 0.056,
                    width: width * 0.22,
                    justifyContent: "flex-end",
                    // backgroundColor: "green",
                  }}
                >
                  <Text style={styles.gpsfontStyl}>00.09</Text>
                </View>
              </View>
            </View>

            <View style={styles.ThirdheadingView}>
              <LinearGradient
                colors={[
                  " rgba(255, 255, 255, 0.2)",
                  " rgba(255, 255, 255, 0.1) ",
                  "rgba(0, 0, 0, 0.2)",
                ]}
                style={styles.lastHeader}
              >
                <View style={styles.MeterTextView}>
                  <Text style={styles.meterTextstyle}>13</Text>
                </View>
                <View style={styles.MeterTextView2}>
                  <Text style={styles.meterTextstyle2}>Meters</Text>
                </View>
              </LinearGradient>
              <LinearGradient
                colors={[
                  " rgba(255, 255, 255, 0.2)",
                  " rgba(255, 255, 255, 0.1) ",
                  "rgba(0, 0, 0, 0.2)",
                ]}
                style={styles.lastHeader}
              >
                <View style={styles.MeterTextView}>
                  <Text style={styles.kmTextstyle}>0.00</Text>
                </View>
                <View style={styles.kmTextView2}>
                  <Text style={styles.meterTextstyle2}>km/h</Text>
                </View>
              </LinearGradient>
              <LinearGradient
                colors={[
                  " rgba(255, 255, 255, 0.2)",
                  " rgba(255, 255, 255, 0.1) ",
                  "rgba(0, 0, 0, 0.2)",
                ]}
                style={styles.lastHeader}
              >
                <View style={styles.EarnedSetmainView}>
                  <View style={styles.EarnedSetChildView}>
                    <View style={styles.EarnedTextView}>
                      <Text style={styles.setTextstyle}>0.00</Text>
                    </View>
                    <View style={styles.kmTextView3}>
                      <Text style={styles.meterTextstyle2}>Earned Set</Text>
                    </View>
                  </View>
                  <View style={styles.dollorLogoView}>
                    <Image
                      style={styles.dollorImageStyle}
                      source={IMAGEPATH.Dollar_white}
                    />
                  </View>
                </View>
              </LinearGradient>
            </View>
            <View style={styles.button_vw}>
              <View style={styles.loginButtonVIew}>
                <AppButton
                  title="SHARE YOUR RUN"
                  ButtonPress={() => props.navigation.navigate("ShareDetails")}
                />
              </View>

              <View style={styles.TextLink}>
                <TouchableOpacity
                  onPress={() => props.navigation.navigate("Home")}
                >
                  <Text style={styles.textlinkstyle}>Back to home</Text>
                </TouchableOpacity>
              </View>
            </View>
          </ImageBackground>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default Share;

const styles = StyleSheet.create({
  textlinkstyle: {
    fontSize: width * 0.045,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "Sen-regular",
  },
  loginButtonVIew: {
    height: height * 0.1,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
  },
  button_vw: {
    height: height * 0.25,
    width: width,
    justifyContent: "center",
    // alignItems: "center",
    /// backgroundColor: "red",
  },
  loginButtonVIew: {
    height: height * 0.11,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    // backgroundColor: "green",
  },

  TextLink: {
    height: height * 0.045,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    marginBottom: height * 0.06,
    // backgroundColor: "green",
  },
  dollorImageStyle: {
    height: height * 0.03,
    width: width * 0.063,
    resizeMode: "contain",
  },
  dollorLogoView: {
    height: height * 0.045,
    width: width * 0.08,
    alignSelf: "center",
    justifyContent: "center",
    //  backgroundColor: "cyan",
  },
  setTextstyle: {
    fontSize: width * 0.066,
    color: "#E838D6",
    textAlign: "center",
    top: height * 0.005,
    fontFamily: "SairaSemiCondensed-bold",
  },
  EarnedTextView: {
    height: height * 0.049,
    width: width * 0.18,
    alignSelf: "center",
    //alignItems: "center",
    //backgroundColor: "blue",
  },
  kmTextView2: {
    height: height * 0.028,
    width: width * 0.19,
    alignSelf: "center",
    justifyContent: "center",
    //  alignItems: "center",
    // backgroundColor: "blue",
  },
  kmTextView3: {
    height: height * 0.025,
    width: width * 0.19,
    justifyContent: "center",
    //alignSelf: "center",
    alignItems: "flex-end",
    // backgroundColor: "blue",
  },
  EarnedSetChildView: {
    // backgroundColor: "green",
    height: height * 0.08,
    width: width * 0.195,
  },
  EarnedSetmainView: {
    // backgroundColor: "red",
    height: height * 0.075,
    width: width * 0.28,
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  kmTextstyle2: {
    fontSize: width * 0.032,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "Sen-regular",
  },
  kmTextstyle: {
    fontSize: width * 0.066,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-bold",
    top: height * 0.005,
  },
  meterTextstyle: {
    fontSize: width * 0.066,
    color: "#01FBB4",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-bold",
    top: height * 0.005,
  },
  meterTextstyle2: {
    fontSize: width * 0.032,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "Sen-regular",
  },
  MeterTextView2: {
    height: height * 0.028,
    width: width * 0.23,
    alignItems: "center",
    alignSelf: "flex-end",
    justifyContent: "center",

    // backgroundColor: "blue",
  },
  MeterTextView: {
    height: height * 0.045,
    width: width * 0.2,
    alignSelf: "center",
    //  alignItems: "center",
    // backgroundColor: "blue",
  },
  MeterTextView: {
    height: height * 0.045,
    width: width * 0.2,
    alignSelf: "center",
    //  alignItems: "center",
    // backgroundColor: "blue",
  },
  lastHeader: {
    height: height * 0.084,
    width: width * 0.28,
    // borderColor: "white",
    // alignItems: "center",
    // justifyContent: "center",
    // backgroundColor: "green",
    alignSelf: "center",
    borderRadius: 10,
    // borderWidth: 1,
    borderColor: "#000000",
    // borderBottomColor: "#00000",
    borderBottomWidth: 0.18,
    shadowColor: "#000000",
    shadowOffset: { width: 0.5, height: 2.5 },
    shadowOpacity: 0.4,
    shadowRadius: 15,
    elevation: 0,
    backdropFilter: "blur",
  },
  ThirdheadingView: {
    // backgroundColor: "green",
    height: height * 0.13,
    width: width * 0.9,
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  gpsVIew: {
    height: height * 0.08,
    width: width * 0.13,
    //   backgroundColor: "blue",
    alignItems: "center",
    // justifyContent: "center",
    alignSelf: "center",
  },
  gpsfontStyl: {
    fontSize: width * 0.075,
    color: "#FFFFFF",
    // textAlign: "center",
    fontFamily: "SairaSemiCondensed-semibold",
  },
  gpsImagestyle: {
    height: height * 0.03,
    width: width * 0.05,
    resizeMode: "contain",
    // alignSelf: "center",
  },
  walkingTextStyle: {
    fontSize: width * 0.035,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-regular",
  },
  stepsTextstyle: {
    fontSize: width * 0.055,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-bold",
  },
  stepsText: {
    // backgroundColor: "pink",
    height: height * 0.04,
    width: width * 0.12,
    justifyContent: "center",
  },
  Steps_IconVIew: {
    // backgroundColor: "pink",
    height: height * 0.04,
    width: width * 0.05,
    justifyContent: "center",
    alignItems: "center",
  },
  stpesIconStyle: {
    height: height * 0.03,
    width: width * 0.06,
    resizeMode: "contain",
  },
  stpesIco: {
    // backgroundColor: "red",
    height: height * 0.08,
    width: width * 0.35,
    //alignSelf: "center",
    flexDirection: "row",
    //alignItems: "center",
  },
  walkingmainVIe: {
    //backgroundColor: "green",
    height: height * 0.08,
    //  width: width * 0.6,
    alignSelf: "center",
    //  flexDirection: "row",
    // alignItems: "center",
  },
  headingView1: {
    //  backgroundColor: "blue",
    height: height * 0.09,
    width: width * 0.95,
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  gpsVIew: {
    height: height * 0.08,
    width: width * 0.13,
    //   backgroundColor: "blue",
    alignItems: "center",
    // justifyContent: "center",
    alignSelf: "center",
  },
  gpsfontStyle: {
    fontSize: width * 0.028,
    color: "#FFFFFF",
    // textAlign: "center",
    fontFamily: "SairaSemiCondensed-bold",
  },
  gpsImagestyle: {
    height: height * 0.03,
    width: width * 0.05,
    resizeMode: "contain",
    // alignSelf: "center",
  },
  walkingTextStyle: {
    fontSize: width * 0.035,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-regular",
  },
  stepsTextstyle: {
    fontSize: width * 0.045,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-bold",
  },
  stepsText: {
    // backgroundColor: "pink",
    height: height * 0.04,
    width: width * 0.12,
    justifyContent: "center",
  },
  Steps_IconVIew: {
    // backgroundColor: "pink",
    height: height * 0.04,
    width: width * 0.05,
    justifyContent: "center",
    alignItems: "center",
  },
  stpesIconStyle: {
    height: height * 0.02,
    width: width * 0.04,
    resizeMode: "contain",
  },
  stpesIcon: {
    // backgroundColor: "red",
    height: height * 0.03,
    width: width * 0.18,
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
  },
  walkingmainVIew: {
    //backgroundColor: "green",
    height: height * 0.08,
    width: width * 0.2,
    alignSelf: "center",
    //  flexDirection: "row",
    alignItems: "center",
  },
  headingView: {
    // backgroundColor: "blue",
    height: height * 0.13,
    width: width * 0.98,
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  humanImageStyle: {
    height: height * 0.95,
    width: width * 0.95,
    resizeMode: "contain",
  },
  mainContainer: {
    height: height,
    width: width,
    // justifyContent:'center'
  },
  ImageBackground: {
    height: height,
    width: width,
    resizeMode: "contain",
    //justifyContent:'center'
  },
});
