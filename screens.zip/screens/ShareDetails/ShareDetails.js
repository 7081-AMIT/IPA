import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Modal,
  Image,
  ImageBackground,
  TouchableOpacity,
  TextInput,
  StatusBar,
  ScrollView,
  SafeAreaView,
} from "react-native";
import React, { useState } from "react";

import { IMAGEPATH } from "../../Icon/Icon";
//import { SafeAreaView } from "react-native-safe-area-context";
//import LinearGradient from "react-native-linear-gradient";
const { height, width } = Dimensions.get("window");
import AppButton from "../../components/CustomButton/CustomButton";

const ShareDetails = (props) => {
  return (
    <SafeAreaView>
      <View style={styles.mainContainer}>
        <ImageBackground
          style={styles.ImageBackground}
          source={IMAGEPATH.SPLASH_BACKGROUND}
        >
          {/* headingView */}
          <View style={styles.headingView}>
            <View style={styles.backView}>
              <TouchableOpacity
                onPress={() => props.navigation.navigate("SportLog")}
              >
                <Image
                  style={{
                    height: height * 0.02,
                    width: width * 0.06,
                  }}
                  source={IMAGEPATH.BACK_ICON}
                />
              </TouchableOpacity>
            </View>

            <View
              style={{
                height: height * 0.06,
                width: width * 0.45,
                //  backgroundColor: "green",
                marginLeft: width * 0.15,
                justifyContent: "center",
              }}
            >
              <Text style={styles.HeadingTextStyle}>10/06/2022</Text>
            </View>
          </View>

          {/* cardView */}

          <View
            style={{
              //  backgroundColor: "blue",
              height: height * 0.26,
              width: width * 0.95,
              alignSelf: "center",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              //justifyContent: "space-around",
            }}
          >
            <Image
              style={{
                resizeMode: "contain",
                height: height * 0.2,
                width: width * 0.9,
              }}
              source={IMAGEPATH.CardLocation}
            />
          </View>
          {/* Menu Icon */}

          <View
            style={{
              // backgroundColor: "blue",
              height: height * 0.45,
              width: width * 0.95,
              alignSelf: "center",
              // flexDirection: "row",
              alignItems: "center",
              //justifyContent: "space-around",
            }}
          >
            <View
              style={{
                // backgroundColor: "green",
                height: height * 0.08,
                width: width * 0.95,
                alignSelf: "center",
                flexDirection: "row",
                alignItems: "center",
                //justifyContent: "space-around",
              }}
            >
              <View style={styles.LoactionView}>
                <Image
                  style={{
                    resizeMode: "cover",
                    height: height * 0.03,
                    width: width * 0.06,
                    // backgroundColor: "green",
                    //   flex: 1,
                  }}
                  source={IMAGEPATH.Location_Icon1}
                />
              </View>
              <View
                style={{
                  height: height * 0.06,
                  width: width * 0.83,
                  // borderColor: "white",
                  alignItems: "center",
                  flexDirection: "row",
                  justifyContent: "space-between",
                  //backgroundColor: "red",
                }}
              >
                <Text style={styles.DistanceTextStyle}>Distance</Text>
                <Text style={styles.DistanceTextStyle}>0 km</Text>
              </View>
            </View>

            {/* second Menu */}
            <View
              style={{
                // backgroundColor: "green",
                height: height * 0.08,
                width: width * 0.95,
                alignSelf: "center",
                flexDirection: "row",
                alignItems: "center",
                //justifyContent: "space-around",
              }}
            >
              <View style={styles.LoactionView}>
                <Image
                  style={{
                    resizeMode: "cover",
                    height: height * 0.03,
                    width: width * 0.06,
                    // backgroundColor: "green",
                    //   flex: 1,
                  }}
                  source={IMAGEPATH.AverageTImer_Icom}
                />
              </View>
              <View
                style={{
                  height: height * 0.06,
                  width: width * 0.83,
                  // borderColor: "white",
                  alignItems: "center",
                  flexDirection: "row",
                  justifyContent: "space-between",
                  // backgroundColor: "red",
                }}
              >
                <Text style={styles.DistanceTextStyle}>Average Speed</Text>
                <Text style={styles.DistanceTextStyle}>0 km/h</Text>
              </View>
            </View>
            {/* Third Menu */}
            <View
              style={{
                // backgroundColor: "green",
                height: height * 0.08,
                width: width * 0.95,
                alignSelf: "center",
                flexDirection: "row",
                alignItems: "center",
                //justifyContent: "space-around",
              }}
            >
              <View style={styles.LoactionView}>
                <Image
                  style={{
                    resizeMode: "cover",
                    height: height * 0.03,
                    width: width * 0.06,
                    // backgroundColor: "green",
                    //   flex: 1,
                  }}
                  source={IMAGEPATH.Timer_Icon}
                />
              </View>
              <View
                style={{
                  height: height * 0.06,
                  width: width * 0.83,
                  // borderColor: "white",
                  alignItems: "center",
                  flexDirection: "row",
                  justifyContent: "space-between",
                  // backgroundColor: "red",
                }}
              >
                <Text style={styles.DistanceTextStyle}>Time</Text>
                <Text style={styles.DistanceTextStyle}>0:00:31</Text>
              </View>
            </View>
            {/* fourth Menu */}
            <View
              style={{
                // backgroundColor: "green",
                height: height * 0.08,
                width: width * 0.95,
                alignSelf: "center",
                flexDirection: "row",
                alignItems: "center",
                //justifyContent: "space-around",
              }}
            >
              <View style={styles.LoactionView}>
                <Image
                  style={{
                    resizeMode: "cover",
                    height: height * 0.03,
                    width: width * 0.06,
                    // backgroundColor: "green",
                    //   flex: 1,
                  }}
                  source={IMAGEPATH.Steps_Icon}
                />
              </View>
              <View
                style={{
                  height: height * 0.06,
                  width: width * 0.83,
                  // borderColor: "white",
                  alignItems: "center",
                  flexDirection: "row",
                  justifyContent: "space-between",
                  // backgroundColor: "red",
                }}
              >
                <Text style={styles.DistanceTextStyle}>Steps</Text>
                <Text style={styles.DistanceTextStyle}>205</Text>
              </View>
            </View>
            {/* fifth Menu */}
            <View
              style={{
                // backgroundColor: "green",
                height: height * 0.08,
                width: width * 0.95,
                alignSelf: "center",
                flexDirection: "row",
                alignItems: "center",
                //justifyContent: "space-around",
              }}
            >
              <View style={styles.LoactionView}>
                <Image
                  style={{
                    resizeMode: "cover",
                    height: height * 0.03,
                    width: width * 0.063,
                    // backgroundColor: "green",
                    //   flex: 1,
                  }}
                  source={IMAGEPATH.Dollar_Icon}
                />
              </View>
              <View
                style={{
                  height: height * 0.06,
                  width: width * 0.83,
                  // borderColor: "white",
                  alignItems: "center",
                  flexDirection: "row",
                  justifyContent: "space-between",
                  // backgroundColor: "red",
                }}
              >
                <Text style={styles.DistanceTextStyle}>Earning</Text>
                <Text style={styles.DistanceTextStyle}>102</Text>
              </View>
            </View>
          </View>
          <View style={styles.button_vw}>
            <View style={styles.loginButtonVIew}>
              <AppButton
                title="SHARE"
                ButtonPress={() => props.navigation.navigate("StartPlay")}
              />
            </View>
          </View>
        </ImageBackground>
      </View>
    </SafeAreaView>
  );
};

export default ShareDetails;

const styles = StyleSheet.create({
  headingView: {
    // backgroundColor: "blue",
    height: height * 0.08,
    width: width * 0.95,
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    //justifyContent: "space-around",
  },
  DistanceTextStyle: {
    fontSize: width * 0.039,
    color: "#FFFFFF",
    //textAlign: "center",
    fontFamily: "Sen-regular",
  },
  HeadingTextStyle: {
    fontSize: width * 0.055,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-Bold",
  },
  backView: {
    height: height * 0.04,
    width: width * 0.11,
    // borderColor: "white",
    alignItems: "center",
    justifyContent: "center",
    // fbackgroundColor: "green",
  },
  LoactionView: {
    height: height * 0.06,
    width: width * 0.11,
    // borderColor: "white",
    alignItems: "center",
    justifyContent: "center",
    //backgroundColor: "green",
  },
  mainContainer: {
    height: height,
    width: width,
    // justifyContent:'center'
  },
  ImageBackground: {
    height: height,
    width: width,
    //justifyContent:'center'
  },
  loginButtonVIew: {
    height: height * 0.1,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
  },
  button_vw: {
    height: height * 0.2,
    width: width,
    //justifyContent: "center",
    alignItems: "center",
    // backgroundColor: "red",
  },
});
