import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Modal,
  Image,
  ImageBackground,
  TouchableOpacity,
  TextInput,
  StatusBar,
  ScrollView,
  SafeAreaView,
  Platform,
  Switch,
} from "react-native";
import React, { useState } from "react";
import { IMAGEPATH } from "../../Icon/Icon";

import LinearGradient from "react-native-linear-gradient";
const { height, width } = Dimensions.get("window");

import { ProgressBar, MD3Colors } from "react-native-paper";
import { LinearTextGradient } from "react-native-text-gradient";
//import ToggleSwitch from "toggle-switch-react-native";

import AppButton from "../../components/CustomButton/CustomButton";
import AppButtonCircle from "../../components/coustomCircleButton/CustomCircleButton";
import AppCircleButtonRed from "../../components/coustomCircleButton/coustomCircleButtonRed";

const EditProfile = (props) => {
  const [Select, setSelect] = useState(false);
  const Radio = () => {
    if (Select == true) {
      setSelect(false);
    } else {
      setSelect(true);
    }
  };
  return (
    <SafeAreaView>
      <ScrollView>
        <View style={styles.mainContainer}>
          <ImageBackground
            style={styles.ImageBackground}
            source={IMAGEPATH.SPLASH_BACKGROUND}
          >
            <View style={styles.headingView}>
              <View style={styles.backView}>
                <TouchableOpacity
                  onPress={() => props.navigation.navigate("Setting")}
                >
                  <Image
                    style={styles.backImage}
                    source={IMAGEPATH.BACK_ICON}
                  />
                </TouchableOpacity>
              </View>
              <View
                style={{
                  height: height * 0.06,
                  width: width * 0.45,
                  //  backgroundColor: "green",
                  marginLeft: width * 0.15,
                  justifyContent: "center",
                }}
              >
                <Text style={styles.HeadingTextStyle}>Edit Profile</Text>
              </View>
              <View>
                <TouchableOpacity
                  onPress={() => props.navigation.navigate("Setting")}
                >
                  <LinearGradient
                    colors={["#CA76C1", "#77CFCF", "#B8FFAE"]}
                    style={{
                      height: height * 0.05,
                      width: width * 0.22,
                      justifyContent: "center",
                      borderRadius: 35,
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <Text style={styles.saveTextstyle}>Save</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </View>
            <LinearGradient
              colors={["rgba(255, 255, 255, 0.2)", "rgba(255, 255, 255, 0)"]}
              style={styles.SettingView}
            >
              <View style={styles.ProfilemainView}>
                <View style={styles.ProfileBorderView}>
                  <LinearGradient
                    colors={[
                      "rgba(255, 255, 255, 0.2)",
                      "rgba(255, 255, 270, 0.1)",
                    ]}
                    style={styles.ProfileBorderView}
                  >
                    <View
                      style={{
                        alignItems: "center",
                        height: height * 0.19,
                        width: width * 0.43,
                        flexDirection: "row",
                        //  backgroundColor: "red",
                        justifyContent: "center",
                        //borderRadius: 95,
                      }}
                    >
                      <View>
                        <Image
                          style={{
                            height: height * 0.11,
                            width: width * 0.22,
                            resizeMode: "contain",
                          }}
                          source={IMAGEPATH.PROFILE_Icon}
                        />
                      </View>
                      <TouchableOpacity
                        style={{
                          height: height * 0.03,
                          width: width * 0.07,

                          borderRadius: 95,
                          backgroundColor: "#3BD0C7",
                          position: "absolute",
                          bottom: height * 0.048,
                          left: width * 0.26,
                          justifyContent: "center",
                          alignItems: "center",
                          // alignSelf: "flex-end",
                        }}
                      >
                        <View
                          style={{
                            height: height * 0.03,
                            width: width * 0.07,

                            borderRadius: 95,
                            //   backgroundColor: "#3BD0C7",
                            // position: "absolute",
                            //   bottom: height * 0.019,
                            //   left: width * 0.27,
                            justifyContent: "center",
                            alignItems: "center",
                            // alignSelf: "flex-end",
                          }}
                        >
                          <Image
                            style={{
                              height: height * 0.015,
                              width: width * 0.035,
                            }}
                            source={IMAGEPATH.Camera_Icon}
                          />
                        </View>
                      </TouchableOpacity>
                    </View>
                  </LinearGradient>
                </View>
              </View>

              <View style={styles.textInputFields}>
                <LinearGradient
                  colors={[
                    "rgba(255, 255, 255, 0.2)",
                    "rgba(255, 255, 255, 0)",
                  ]}
                  style={styles.editView}
                >
                  <View
                    style={{
                      width: width * 0.72,
                      alignSelf: "center",
                      //backgroundColor: "blue",
                    }}
                  >
                    <TextInput
                      placeholder="First Name"
                      placeholderTextColor={"#A3A3A3"}
                      style={{
                        fontFamily: "sen-regular",
                        color: "#A3A3A3",
                        fontSize: width * 0.042,
                      }}
                      maxLength={60}
                    />
                  </View>
                </LinearGradient>
                <LinearGradient
                  colors={[
                    "rgba(255, 255, 255, 0.2)",
                    "rgba(255, 255, 255, 0)",
                  ]}
                  style={styles.editView}
                >
                  <View
                    style={{
                      width: width * 0.72,
                      alignSelf: "center",
                      //backgroundColor: "blue",
                    }}
                  >
                    <TextInput
                      placeholder="Last Name"
                      placeholderTextColor={"#A3A3A3"}
                      style={{
                        fontFamily: "sen-regular",
                        color: "#A3A3A3",
                        fontSize: width * 0.042,
                      }}
                      maxLength={60}
                    />
                  </View>
                </LinearGradient>
                <LinearGradient
                  colors={[
                    "rgba(255, 255, 255, 0.2)",
                    "rgba(255, 255, 255, 0.1)",
                  ]}
                  style={styles.editView2}
                >
                  <View
                    style={{
                      width: width * 0.72,
                      alignSelf: "center",
                      //backgroundColor: "blue",
                    }}
                  >
                    <TextInput
                      placeholder="Bio"
                      placeholderTextColor={"#A3A3A3"}
                      style={{
                        fontFamily: "sen-regular",
                        color: "#A3A3A3",
                        fontSize: width * 0.042,
                      }}
                      // maxLength={60}
                    />
                  </View>
                </LinearGradient>
                <View
                  style={{
                    height: height * 0.07,
                    width: width * 0.55,
                    marginLeft: width * 0.08,
                    // alignSelf: "center",
                    //  backgroundColor: "blue",
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <TouchableOpacity onPress={() => Radio()}>
                    <View
                      style={{
                        borderWidth: 2,
                        borderLeftColor: "rgb(140,186,203)",
                        borderRightColor: "rgb(140,186,203)",
                        borderBottomColor: "rgb(183,255,178)",
                        borderTopColor: "rgb(203,117,191)",
                        borderRadius: 35,
                      }}
                    >
                      <LinearGradient
                        colors={
                          Select !== true
                            ? ["transparent", "transparent"]
                            : ["#CA76C1", "#77CFCF", "#B8FFAE"]
                        }
                        style={{
                          height: height * 0.04,
                          width: width * 0.25,
                          justifyContent: "center",
                          borderRadius: 35,
                          justifyContent: "center",
                          alignItems: "center",
                        }}
                      >
                        <Text style={styles.saveTextstyle}>Male</Text>
                      </LinearGradient>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => Radio()}>
                    <View
                      style={{
                        borderWidth: 2,
                        borderBottomColor: "rgb(161,239,188)",
                        borderLeftColor: "rgb(121,211,204)",
                        borderRightColor: "rgb(121,211,204)",
                        borderTopColor: "rgb(184,138,194)",
                        borderRadius: 35,
                      }}
                    >
                      <LinearGradient
                        colors={
                          Select == true
                            ? ["transparent", "transparent"]
                            : ["#CA76C1", "#77CFCF", "#B8FFAE"]
                        }
                        style={{
                          height: height * 0.04,
                          width: width * 0.25,
                          justifyContent: "center",
                          borderRadius: 35,
                          justifyContent: "center",
                          alignItems: "center",
                        }}
                      >
                        <Text style={styles.saveTextstyle}>Female</Text>
                      </LinearGradient>
                    </View>
                  </TouchableOpacity>
                </View>
                <View
                  style={{
                    height: height * 0.09,
                    // backgroundColor: "blue",
                  }}
                >
                  <LinearGradient
                    colors={[
                      "rgba(255, 255, 255, 0.2)",
                      "rgba(255, 255, 255, 0)",
                    ]}
                    style={styles.editView}
                  >
                    <View
                      style={{
                        width: width * 0.72,
                        alignSelf: "center",
                        //backgroundColor: "blue",
                      }}
                    >
                      <TextInput
                        placeholder="Email address"
                        placeholderTextColor={"#A3A3A3"}
                        style={{
                          fontFamily: "sen-regular",
                          color: "#A3A3A3",
                          fontSize: width * 0.042,
                        }}
                        maxLength={30}
                        keyboardType="email-address"
                      />
                    </View>
                  </LinearGradient>
                </View>
                <TouchableOpacity
                  onPress={() => props.navigation.navigate("Weight")}
                >
                  <LinearGradient
                    colors={[
                      "rgba(255, 255, 255, 0.2)",
                      "rgba(255, 255, 255, 0)",
                    ]}
                    style={styles.editView}
                  >
                    <View
                      style={{
                        height: height * 0.06,
                        width: width * 0.75,
                        flexDirection: "row",
                        //  backgroundColor: "blue",
                        alignSelf: "center",
                        alignItems: "center",
                        justifyContent: "space-between",
                      }}
                    >
                      <Text
                        style={{
                          fontFamily: "",
                          color: "#A3A3A3",
                          fontSize: width * 0.042,
                          fontFamily: "SairaSemiCondensed-Bold",
                        }}
                      >
                        Weight
                      </Text>
                      <View
                        style={{
                          height: height * 0.04,
                          width: width * 0.55,
                          // backgroundColor: "blue",
                          flexDirection: "row",
                          justifyContent: "flex-end",
                          alignItems: "center",
                          // alignItems: "baseline",
                        }}
                      >
                        <Text
                          style={{
                            fontFamily: "",
                            color: "#FFFFFF",
                            fontSize: width * 0.042,
                            fontFamily: "sen-regular",
                            textAlign: "center",
                          }}
                        >
                          65.5
                        </Text>
                        <Text
                          style={{
                            fontFamily: "",
                            color: "#FFFFFF",
                            fontSize: width * 0.042,
                            fontFamily: "Sen-regular",
                          }}
                        >
                          KG
                        </Text>
                      </View>
                      <Image
                        style={{
                          height: height * 0.02,
                          width: width * 0.04,
                          resizeMode: "contain",
                        }}
                        source={IMAGEPATH.Forword_Icon}
                      />
                    </View>
                  </LinearGradient>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => props.navigation.navigate("Height")}
                >
                  <LinearGradient
                    colors={[
                      "rgba(255, 255, 255, 0.2)",
                      "rgba(255, 255, 255, 0)",
                    ]}
                    style={styles.editView}
                  >
                    <View
                      style={{
                        height: height * 0.06,
                        width: width * 0.75,
                        flexDirection: "row",
                        //  backgroundColor: "blue",
                        alignSelf: "center",
                        alignItems: "center",
                        justifyContent: "space-between",
                      }}
                    >
                      <Text
                        style={{
                          fontFamily: "",
                          color: "#A3A3A3",
                          fontSize: width * 0.042,
                          fontFamily: "SairaSemiCondensed-Bold",
                        }}
                      >
                        Height
                      </Text>
                      <View
                        style={{
                          height: height * 0.04,
                          width: width * 0.55,
                          // backgroundColor: "blue",
                          flexDirection: "row",
                          justifyContent: "flex-end",
                          alignItems: "center",
                          // alignItems: "baseline",
                        }}
                      >
                        <Text
                          style={{
                            fontFamily: "",
                            color: "#FFFFFF",
                            fontSize: width * 0.042,
                            fontFamily: "sen-regular",
                            textAlign: "center",
                          }}
                        >
                          65.5
                        </Text>
                        <Text
                          style={{
                            fontFamily: "",
                            color: "#FFFFFF",
                            fontSize: width * 0.042,
                            fontFamily: "Sen-regular",
                          }}
                        >
                          CM
                        </Text>
                      </View>
                      <Image
                        style={{
                          height: height * 0.02,
                          width: width * 0.04,
                          resizeMode: "contain",
                        }}
                        source={IMAGEPATH.Forword_Icon}
                      />
                    </View>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </LinearGradient>
          </ImageBackground>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default EditProfile;

const styles = StyleSheet.create({
  editView2: {
    height: height * 0.095,
    width: width * 0.85,
    alignSelf: "center",
    //  backgroundColor: "green",
    justifyContent: "center",
    borderRadius: 15,
    //  marginTop: height * 0.02,

    // alignItems: "center",
  },
  editView: {
    height: height * 0.07,
    width: width * 0.85,
    alignSelf: "center",
    //  backgroundColor: "green",
    justifyContent: "center",
    borderRadius: 15,
    //  marginTop: height * 0.02,

    // alignItems: "center",
  },
  textInputFields: {
    height: height * 0.7,
    width: width * 0.98,
    // backgroundColor: "blue",
    alignSelf: "center",
    justifyContent: "space-evenly",
  },
  SettingView: {
    height: height * 1,
    width: width * 0.994,
    alignSelf: "center",
    // borderTopRightadius: 40,
    // borderTopLeftRadius: 40,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    marginTop: height * 0.01,
    shadowColor: "#0000000",
    shadowOffset: { width: 0.2, height: 2 },
    shadowOpacity: Platform.OS === "android" ? 0 : 0.1,
    shadowRadius: Platform.OS === "android" ? 0 : 15,
    elevation: Platform.OS === "android" ? 0 : 2,
    // backgroundColor: "blue",
    // backdropFilter: "blur",
  },
  saveTextstyle: {
    fontSize: width * 0.035,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "sen-regular",
  },
  ProfileBorderView: {
    height: height * 0.13,
    width: width * 0.28,
    // alignSelf: "center",
    borderRadius: 100,
    borderWidth: 1,
    // backgroundColor: "red",
    borderLeftColor: "rgb(140,186,203)",
    borderRightColor: "rgb(140,186,203)",
    borderBottomColor: "rgb(183,255,178)",
    borderTopColor: "rgb(203,117,191)",
    // flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    //  backgroundColor: "green",
    //justifyContent: "space-around",
  },
  ProfilemainView: {
    height: height * 0.2,
    width: width * 0.89,
    alignSelf: "center",
    justifyContent: "center",
    // flexDirection: "row",
    // alignItems: "center",
    // backgroundColor: "blue",
    //justifyContent: "space-around",
  },
  HeadingTextStyle: {
    fontSize: width * 0.06,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-Bold",
  },
  backView: {
    height: height * 0.04,
    width: width * 0.11,
    // borderColor: "white",
    alignItems: "center",
    justifyContent: "center",
    // fbackgroundColor: "green",
  },
  headingView: {
    // backgroundColor: "blue",
    height: height * 0.08,
    width: width * 0.95,
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    //justifyContent: "space-around",
  },
  mainContainer: {
    height: height,
    width: width,
    // justifyContent:'center'
  },
  ImageBackground: {
    height: height,
    width: width,
    resizeMode: "contain",
    //justifyContent:'center'
  },
});
