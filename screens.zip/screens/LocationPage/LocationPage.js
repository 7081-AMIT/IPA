import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Modal,
  Image,
  ImageBackground,
  TouchableOpacity,
  TextInput,
  StatusBar,
} from "react-native";
import React, { useState } from "react";
import LinearGradient from "react-native-linear-gradient";
import { IMAGEPATH } from "../../Icon/Icon";
const { height, width } = Dimensions.get("window");
const LocationPage = (props) => {
  return (
    <View style={styles.mainContainer}>
      <ImageBackground
        style={styles.ImageBackground}
        source={IMAGEPATH.SPLASH_BACKGROUND}
      >
        <View style={styles.fakeView}></View>
        <View style={styles.ImageVIew}>
          {/* <LinearGradient
            colors={["#CA76C1", "#77CFCF", "#B8FFAE"]}
            style={{
              height: height * 0.35,
              width: width * 0.9,
              justifyContent: "center",
              borderRadius: 10,
            }}
          > */}
          <View style={[styles.LOCATION_BG, styles.border_color]}>
            <View style={styles.HeadingView}>
              <Text style={styles.headingText}>Use your location</Text>
            </View>
            <View style={styles.paraTextView}>
              <Text style={styles.paraTextStyle}>
                Lorem ipsum dolor sit amet, consectetur {"\n"}adipiscing elit
                Velit fusce mauris augue {"\n"}urna, elit lacus sit lacus.
              </Text>
            </View>
            <View style={styles.AllowButton}>
              <TouchableOpacity
                onPress={() => props.navigation.navigate("Home")}
              >
                <View style={[styles.allow, styles.border_color]}>
                  <View style={styles.textButtonVIew}>
                    <Text style={styles.textButton}>Allow</Text>
                  </View>
                </View>
              </TouchableOpacity>
            </View>
          </View>
          {/* </LinearGradient> */}
        </View>
      </ImageBackground>
    </View>
  );
};

export default LocationPage;

const styles = StyleSheet.create({
  textButtonVIew: {
    height: height * 0.05,
    width: width * 0.12,
    justifyContent: "center",
  },
  textButton: {
    fontSize: height / 60,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "Sen-Regular",
  },
  BUTTON_Border: {
    height: height * 0.06,
    width: width * 0.28,
    alignSelf: "center",
    alignItems: "center",
  },

  headingText: {
    fontSize: height / 30,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-Medium",
    fontWeight: "500",
  },
  LOCATION_BG: {
    height: height * 0.4,
    width: width * 0.9,
    alignSelf: "center",
    borderRadius: 10,
    backgroundColor: "rgba(255, 255, 255, 0.1)",
  },
  mainContainer: {
    height: height,
    width: width,
  },
  ImageBackground: {
    height: height,
    width: width,
  },
  fakeView: {
    height: height * 0.3,
  },
  fakeView1: {
    height: height * 0.05,
    width: width * 0.35,
    alignSelf: "center",
  },
  ImageVIew: {
    height: height * 0.45,
    width: width * 0.95,
    borderColor: "white",
    alignSelf: "center",
    justifyContent: "center",
  },
  HeadingView: {
    height: height * 0.12,
    width: width * 0.87,
    alignSelf: "center",
    justifyContent: "center",
  },
  paraTextView: {
    height: height * 0.15,
    width: width * 0.88,
    alignSelf: "center",
  },
  paraTextStyle: {
    fontSize: height / 70,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "Sen-Regular",
    fontWeight: "400",
    lineHeight: height * 0.025,
  },
  AllowButton: {
    height: height * 0.08,
    width: width * 0.8,
    alignSelf: "center",
  },
  allow: {
    height: height * 0.06,
    width: width * 0.3,
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 30,
  },
  border_color: {
    borderWidth: 0.8,
    borderTopColor: "rgba(202, 118, 193, 1)",
    borderBottomColor: "rgba(184, 255, 174, 1)",
    borderLeftColor: "rgba(119, 207, 207, 1)",
    borderRightColor: "rgba(119, 207, 207, 1)",
  },
});
