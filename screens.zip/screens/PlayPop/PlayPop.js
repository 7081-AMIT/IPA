import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Modal,
  Image,
  ImageBackground,
  TouchableOpacity,
  TextInput,
  StatusBar,
  ScrollView,
  SafeAreaView,
  Platform,
} from "react-native";
import React, { useState } from "react";
import { IMAGEPATH } from "../../Icon/Icon";
//import { SafeAreaView } from "react-native-safe-area-context";
import LinearGradient from "react-native-linear-gradient";
const { height, width } = Dimensions.get("window");
// import SimpleGradientProgressbarView from "react-native-simple-gradient-progressbar-view";
// import SimpleGradientProgressbarView from "react-native-simple-gradient-progressbar-view";
import { ProgressBar, MD3Colors } from "react-native-paper";
import { LinearTextGradient } from "react-native-text-gradient";

//import { LinearTextGradient } from "react-native-text-gradient";

//import { ProgressBarAndroid } from "react-native";

import AppButton from "../../components/CustomButton/CustomButton";
import AppButtonCircle from "../../components/coustomCircleButton/CustomCircleButton";

const PlayPop = (props) => {
  const [modalVisible, setModalVisible] = useState(false);
  return (
    <SafeAreaView>
      <ScrollView>
        <View style={styles.mainContainer}>
          <ImageBackground
            style={styles.ImageBackground}
            source={IMAGEPATH.SPLASH_BACKGROUND}
          >
            {/* Modal */}

            <Modal
              animationType="slide"
              transparent={true}
              visible={modalVisible}
              onRequestClose={() => {
                Alert.alert("Modal has been closed.");
                setModalVisible(!modalVisible);
              }}
            >
              <View
                style={{
                  flex: 1,
                  justifyContent: "center",
                }}
              >
                <LinearGradient
                  colors={[
                    "rgba(255, 255, 255, 0.2)",
                    "rgba(255, 255, 254, 0)",
                  ]}
                  style={{
                    flex: 1,
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <ImageBackground
                    style={{
                      width: width * 0.95,
                      height: height * 0.4,
                      justifyContent: "center",
                      resizeMode: "contain",
                      alignSelf: "center",
                    }}
                    source={IMAGEPATH.Modal_PopUp}
                  >
                    <View
                      style={{
                        flexDirection: "column",
                        height: height * 0.25,
                        justifyContent: "space-evenly",
                      }}
                    >
                      <View style={{ alignSelf: "center" }}>
                        <Text
                          style={{
                            fontSize: width * 0.055,
                            fontWeight: "500",
                            color: "white",
                          }}
                        >
                          NOTICE
                        </Text>
                      </View>
                      <View style={{ alignSelf: "center", width: width * 0.7 }}>
                        <Text
                          style={{
                            fontSize: width * 0.045,
                            fontWeight: "400",
                            color: "white",
                            textAlign: "center",
                          }}
                        >
                          You cannot earn token without Sneaker. Continue?
                        </Text>
                      </View>
                      <View
                        style={{
                          height: height * 0.08,
                          width: width * 0.75,
                          // backgroundColor: "red",
                          alignSelf: "center",
                          flexDirection: "row",
                          justifyContent: "space-between",
                        }}
                      >
                        <TouchableOpacity
                          onPress={() => setModalVisible(!modalVisible)}
                        >
                          <View
                            style={{
                              height: height * 0.055,
                              width: width * 0.35,
                              justifyContent: "center",
                              borderRadius: 25,
                              alignItems: "center",
                              backgroundColor: "treansparent",
                              borderWidth: 2,
                              borderTopColor: "rgb(183,117,181)",
                              borderRightColor: "rgb(124,213,203)",
                              borderLeftColor: "rgb(124,213,203)",
                              borderBottomColor: "rgb(183,255,178)",
                            }}
                          >
                            <View style={[styles.loginTextView3]}>
                              <Text style={styles.loginTextStyle}>Cancel</Text>
                            </View>
                          </View>
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() => [
                            props.navigation.navigate("Play"),
                            setModalVisible(!modalVisible),
                          ]}
                        >
                          <LinearGradient
                            colors={["#CA76C1", "#77CFCF", "#B8FFAE"]}
                            style={{
                              height: height * 0.055,
                              width: width * 0.35,
                              justifyContent: "center",
                              borderRadius: 25,
                              alignItems: "center",
                            }}
                          >
                            <View style={[styles.loginTextView3]}>
                              <Text style={styles.loginTextStyle}>
                                Continue
                              </Text>
                            </View>
                          </LinearGradient>
                        </TouchableOpacity>
                      </View>
                    </View>
                  </ImageBackground>
                </LinearGradient>
              </View>
            </Modal>

            {/* headingView */}
            <View style={styles.headingView}>
              <View style={styles.backView}>
                <TouchableOpacity
                  onPress={() => props.navigation.navigate("StartPlay")}
                >
                  <Image
                    style={styles.backImage}
                    source={IMAGEPATH.BACK_ICON}
                  />
                </TouchableOpacity>
              </View>

              <View style={styles.headingmidView}>
                <View style={styles.headingchildmidView}>
                  <View
                    style={{
                      height: height * 0.045,
                      width: width * 0.3,
                      // backgroundColor: "blue",
                      // marginLeft: width * 0.03,
                      // justifyContent: "space-around",
                      flexDirection: "row",
                    }}
                  >
                    <View style={styles.DollarImageView}>
                      <Image
                        style={{
                          height: height * 0.03,
                          width: width * 0.064,
                          resizeMode: "contain",
                        }}
                        source={IMAGEPATH.Dollar_white}
                      />
                    </View>
                    <View style={styles.TextView}>
                      <Text style={styles.BarTextStyle}>30/100</Text>
                    </View>
                  </View>
                  <View style={styles.progressbarView}>
                    <ProgressBar
                      progress={0.5}
                      color={"#77CFCF"}
                      style={{
                        height: height * 0.01,
                        width: width * 0.26,
                        borderWidth: 1,
                        borderColor: "#8EC6A9",
                        borderRadius: 10,
                        backgroundColor: "transparent",
                      }}
                    />
                  </View>
                </View>

                <View
                  style={{
                    height: height * 0.081,
                    width: width * 0.3,
                    //  backgroundColor: "red",
                    marginLeft: width * 0.01,
                    //justifyContent: "center",
                    // flexDirection: "row",
                  }}
                >
                  <View
                    style={{
                      height: height * 0.045,
                      width: width * 0.3,
                      // backgroundColor: "blue",
                      // marginLeft: width * 0.03,
                      // justifyContent: "space-evenly",
                      flexDirection: "row",
                    }}
                  >
                    <View style={styles.DollarImageView}>
                      <Image
                        style={{
                          height: height * 0.03,
                          width: width * 0.064,
                          resizeMode: "contain",
                        }}
                        source={IMAGEPATH.Dollar_white}
                      />
                    </View>
                    <View style={styles.TextView}>
                      <Text style={styles.BarTextStyle}>30/100</Text>
                    </View>
                  </View>
                  <View style={styles.progressbarView}>
                    <ProgressBar
                      progress={0.5}
                      color={"#77CFCF"}
                      style={{
                        height: height * 0.01,
                        width: width * 0.27,
                        borderWidth: 1,
                        borderColor: "#8EC6A9",
                        borderRadius: 10,
                        backgroundColor: "transparent",
                      }}
                    />
                  </View>
                </View>
                <View style={styles.ProfileView}>
                  <TouchableOpacity>
                    <Image
                      style={styles.ProfileImageStyle}
                      source={IMAGEPATH.PROFILE_Icon}
                    />
                  </TouchableOpacity>
                </View>
              </View>
            </View>
            <View style={styles.secondView}>
              <View style={styles.secondChildView}>
                <View
                  style={{
                    height: height * 0.055,
                    width: width * 0.6,
                    backgroundColor: "#3587C1",
                    alignItems: "center",
                    alignSelf: "center",
                    borderRadius: 30,
                    // marginLeft: width * 0.15,
                    justifyContent: "center",
                  }}
                >
                  <Text style={styles.HeadingTextStyle}>Umair Siddiqui</Text>
                </View>
              </View>
              <View style={styles.secondChildView1}>
                <View
                  style={{
                    height: height * 0.06,
                    width: width * 0.1,
                    alignSelf: "center",
                    //backgroundColor: "green",
                    // marginLeft: width * 0.15,
                    justifyContent: "center",
                  }}
                >
                  <Text style={styles.ParagraphTextStyle}>Weight</Text>
                </View>
                <View
                  style={{
                    height: height * 0.045,
                    width: width * 0.22,
                    alignSelf: "center",
                    borderRadius: 30,
                    backgroundColor: "#3BD0C7",
                    // marginLeft: width * 0.15,
                    justifyContent: "center",
                  }}
                >
                  <Text style={styles.weightTextStyle}>65 KG</Text>
                </View>
                <View
                  style={{
                    height: height * 0.055,
                    width: width * 0.25,
                    alignSelf: "center",
                    // borderRadius: 30,
                    //backgroundColor: "#3BD0C7",
                    // marginLeft: width * 0.15,
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Text style={styles.ParagraphTextStyle1}>Male</Text>
                </View>
                <View
                  style={{
                    height: height * 0.06,
                    width: width * 0.1,
                    alignSelf: "center",
                    // backgroundColor: "green",
                    // marginLeft: width * 0.15,
                    justifyContent: "center",
                  }}
                >
                  <Text style={styles.ParagraphTextStyle}>Height</Text>
                </View>
                <View
                  style={{
                    height: height * 0.045,
                    width: width * 0.22,
                    alignSelf: "center",
                    borderRadius: 30,
                    backgroundColor: "#964BBA",
                    // marginLeft: width * 0.15,
                    justifyContent: "center",
                  }}
                >
                  <Text style={styles.weightTextStyle}>65.5 CM</Text>
                </View>
              </View>
            </View>
            <View style={styles.humanView}>
              <Image
                style={styles.humanImageStyle}
                source={IMAGEPATH.MALE_ICON}
              />
            </View>
            <View style={styles.tabView}>
              <View style={styles.loginButtonVIew}>
                <TouchableOpacity>
                  <LinearGradient
                    colors={[
                      "rgba(255, 255, 255, 0.2)",
                      "rgba(255, 255, 270, 0.1)",
                    ]}
                    style={styles.tabButton}
                  >
                    <View
                      style={{
                        height: height * 0.08,
                        width: width * 0.13,
                        //   backgroundColor: "blue",
                        alignItems: "center",
                        justifyContent: "center",
                        alignSelf: "center",
                      }}
                    >
                      <Image
                        style={{
                          height: height * 0.06,
                          width: width * 0.12,
                          resizeMode: "contain",
                          // alignSelf: "center",
                        }}
                        source={IMAGEPATH.Shoes_Icon}
                      />
                    </View>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
              <View style={styles.loginButtonVIew1}>
                <AppButtonCircle
                  title="START"
                  ButtonPress={() => setModalVisible(!modalVisible)}
                />
              </View>
              <View style={styles.loginButtonVIew}>
                <TouchableOpacity>
                  <LinearGradient
                    colors={[
                      "rgba(255, 255, 255, 0.2)",
                      "rgba(255, 255, 270, 0.1)",
                    ]}
                    style={styles.tabButton}
                  >
                    <View style={styles.gpsVIew}>
                      <Text style={styles.gpsfontStyle}>GPS</Text>
                      <Image
                        style={styles.gpsImagestyle}
                        source={IMAGEPATH.GPS_Icon}
                      />
                    </View>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </View>
          </ImageBackground>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default PlayPop;

const styles = StyleSheet.create({
  loginTextStyle: {
    fontSize: 14,
    color: '#FFFFFF',
    // fontFamily: 'Sen-regular',
    textAlign: 'center',
    fontWeight: '700',
  },

  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    // marginTop: 22,
    // backgroundColor: "green",
    // borderBottomWidth: 0.2,
    shadowColor: '#000000',
    shadowOffset: {width: 0.2, height: 2.9},
    shadowOpacity: 0.15,
    shadowRadius: 15,
    elevation: 0,
    backdropFilter: 'blur',
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  modalMainView: {
    height: height * 1,
    width: width * 0.1,
    justifyContent: 'center',
  },
  tabButton: {
    height: width * 0.2,
    width: width * 0.2,
    justifyContent: 'center',
    borderRadius:
      Math.round(
        Dimensions.get('window').width + Dimensions.get('window').height,
      ) / 2,
    borderBottomWidth: 0.2,
    shadowColor: '#0000000',
    shadowOffset: {width: 0.5, height: 2.5},
    shadowOpacity: Platform.OS === 'android' ? 0.4 : 0.4,
    shadowRadius: Platform.OS === 'android' ? 15 : 15,
    elevation: Platform.OS === 'android' ? 0 : 3,
    backdropFilter: 'blur',
  },
  gpsVIew: {
    height: height * 0.08,
    width: width * 0.13,
    //   backgroundColor: "blue",
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  gpsfontStyle: {
    fontSize: width * 0.025,
    color: '#FFFFFF',
    // textAlign: "center",
    fontFamily: 'SairaSemiCondensed-regular',
  },
  gpsImagestyle: {
    height: height * 0.03,
    width: width * 0.06,
    resizeMode: 'contain',
    // alignSelf: "center",
  },
  loginButtonVIew1: {
    height: height * 0.14,
    width: width * 0.25,
    alignSelf: 'center',
    // alignItems: "center",
    justifyContent: 'center',
    // backgroundColor: "blue",
  },
  loginButtonVIew: {
    height: height * 0.12,
    width: width * 0.22,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    // backgroundColor: "blue",
  },
  tabView: {
    height: Platform.OS === 'android' ? height * 0.15 : height * 0.14,
    width: width * 0.92,
    // borderColor: "white",
    // alignItems: "center",
    //marginTop: Platform.OS === "android"? height*0.15 : height*0.00,
    alignSelf: 'center',
    marginTop: Platform.OS === 'android' ? height * 0.04 : height * 0.0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    // backgroundColor: 'green',
  },
  LoactionView: {
    height: height * 0.06,
    width: width * 0.08,
    // borderColor: "white",
    alignItems: 'center',
    // justifyContent: "center",
    //backgroundColor: "green",
  },
  ThirdView: {
    height: height * 0.12,
    width: width * 0.98,
    // borderColor: "white",
    // alignItems: "center",
    // justifyContent: "center",
    // backgroundColor: "green",
    alignSelf: 'center',
    // borderWidth: 1,
    // borderColor: "",
    // borderBottomColor: "#00000",
    borderBottomWidth: 0.2,
    shadowColor: '#000000',
    shadowOffset: {width: 0.9, height: 2.5},
    shadowOpacity: 0.4,
    shadowRadius: 15,
    elevation: 0,
    backdropFilter: 'blur',
  },
  humanImageStyle: {
    height: height * 0.8,
    width: width * 0.8,
    resizeMode: 'contain',
  },
  humanView: {
    height: height * 0.4,
    width: width * 0.85,
    // borderColor: "white",
    alignItems: 'center',
    justifyContent: 'center',
    //backgroundColor: "blue",
    alignSelf: 'center',
    // borderWidth: 1,
  },
  weightTextStyle: {
    fontSize: width * 0.04,
    color: '#FFFFFF',
    textAlign: 'center',

    fontFamily: 'Sen-Regular',
  },
  ParagraphTextStyle: {
    fontSize: width * 0.03,
    color: '#FFFFFF',
    // textAlign: "center",
    fontFamily: 'SairaSemiCondensed-regular',
  },
  ParagraphTextStyle2: {
    fontSize: width * 0.035,
    color: '#FFFFFF',
    // textAlign: "center",
    fontFamily: 'SairaSemiCondensed-regular',
  },
  ParagraphTextStyle1: {
    fontSize: width * 0.045,
    color: '#FFFFFF',
    textAlign: 'center',
    fontFamily: 'SairaSemiCondensed-regular',
  },
  textlinkstyle: {
    fontSize: width * 0.045,
    color: '#FFFFFF',
    textAlign: 'center',
    fontFamily: 'SairaSemiCondensed-regualr',
  },
  stepsTextStyle1: {
    fontSize: width * 0.085,
    color: '#FFFFFF',
    textAlign: 'center',
    fontFamily: 'SairaSemiCondensed-regualar',
  },
  HeadingTextStyle: {
    fontSize: width * 0.055,
    color: '#FFFFFF',
    //textAlign: "center",
    fontFamily: 'SairaSemiCondensed-Bold',
  },
  secondChildView: {
    height: height * 0.075,
    width: width * 0.88,
    alignSelf: 'center',
    // backgroundColor: "red",
    // marginLeft: width * 0.01,
    justifyContent: 'center',
    // flexDirection: "row",
  },
  secondChildView1: {
    height: height * 0.075,
    width: width * 0.92,
    alignSelf: 'center',
    //backgroundColor: "red",
    marginLeft: width * 0.04,
    // justifyContent: "space-between",
    flexDirection: 'row',
  },
  secondView: {
    height: height * 0.19,
    width: width * 0.98,
    // borderColor: "white",
    // alignItems: "center",
    // justifyContent: "center",
    // backgroundColor: "green",
    alignSelf: 'center',
    // borderWidth: 1,
    borderColor: '#000000',
    // borderBottomColor: "#00000",
    //  borderBottomWidth: 0.18,
    shadowColor: '#000000',
    shadowOffset: {width: 0.9, height: 2.5},
    shadowOpacity: 0.4,
    shadowRadius: 15,
    elevation: 0,
    backdropFilter: 'blur',
  },
  ProfileImageStyle: {
    height: height * 0.062,
    width: width * 0.13,
    resizeMode: 'contain',
  },
  ProfileView: {
    height: height * 0.07,
    width: width * 0.2,
    // borderColor: "white",
    alignItems: 'center',
    justifyContent: 'center',
    // backgroundColor: "green",
    alignSelf: 'center',
  },

  headingchildmidView: {
    height: height * 0.081,
    width: width * 0.3,
    //backgroundColor: "red",
    marginLeft: width * 0.01,
    //justifyContent: "center",
    // flexDirection: "row",
  },
  headingmidView: {
    height: height * 0.08,
    width: width * 0.65,
    // backgroundColor: "green",
    marginLeft: width * 0.01,
    //justifyContent: "center",
    flexDirection: 'row',
  },
  progressbarView: {
    height: height * 0.02,
    width: width * 0.27,
    // backgroundColor: "yellow",
    // marginLeft: width * 0.01,
    justifyContent: 'center',
    //flexDirection: "row",
  },
  backImage: {
    height: height * 0.02,
    width: width * 0.06,
    resizeMode: 'contain',
  },
  SettingImage: {
    height: height * 0.04,
    width: width * 0.09,
    resizeMode: 'contain',
  },

  headingView: {
    //backgroundColor: "blue",
    height: height * 0.13,
    width: width * 0.95,
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    //justifyContent: "space-",
  },
  box: {
    width: width * 0.3,
    height: height * 0.02,
    marginVertical: 20,
    borderColor: 'white',
    borderWidth: 2,
    borderRadius: 20,
  },
  BarTextStyle: {
    fontSize: width * 0.045,
    color: '#FFFFFF',
    // textAlign: "center",
    fontFamily: 'SairaSemiCondensed-Regular',
  },
  TextView: {
    height: height * 0.04,
    width: width * 0.18,
    // borderColor: "white",
    // alignItems: "center",
    justifyContent: 'center',
    // backgroundColor: "green",
  },
  backView: {
    height: height * 0.04,
    width: width * 0.11,
    // borderColor: "white",
    alignItems: 'center',
    justifyContent: 'center',
    // backgroundColor: "green",
  },
  settingView: {
    height: height * 0.06,
    width: width * 0.11,
    // borderColor: "white",
    // alignSelf: "center",
    alignItems: 'center',
    justifyContent: 'center',
    // backgroundColor: "green",
  },
  DollarImageView: {
    height: height * 0.04,
    width: width * 0.075,
    // borderColor: "white",
    // alignItems: "center",
    justifyContent: 'center',
    //  backgroundColor: "blue",
  },
  mainContainer: {
    height: height,
    width: width,
    // justifyContent:'center'
  },
  ImageBackground: {
    height: height,
    width: width,
    //justifyContent:'center'
  },
});
