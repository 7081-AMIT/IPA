// import {
//     StyleSheet,
//     Text,
//     View,
//     Dimensions,
//     Modal,
//     Image,
//     ImageBackground,
//     TouchableOpacity,
//     TextInput,
//     StatusBar,

// } from 'react-native'
// import React, { useState } from 'react';
// import { IMAGEPATH } from "../../Icon/Icon";
// // import Svg, {Pie} from 'react-native-svg';
// import SimpleGradientProgressbarView from "react-native-simple-gradient-progressbar-view";
// import LinearGradient from 'react-native-linear-gradient';
// import * as Progress from 'react-native-progress';
// const { height, width } = Dimensions.get("window");

// const ShoesSelector = () => {
//     return (
//         <View style={styles.mainContainer}>
//             <ImageBackground
//                 style={styles.ImageBackground}
//                 source={IMAGEPATH.SPLASH_BACKGROUND}
//             >
//                 <StatusBar barStyle="light-content"></StatusBar>
//                 <View style={styles.fakeView}></View>
//                 <View style={styles.HeadingView}>

//                     <View style={styles.ProfileVIew}>
//                         <Image style={styles.PROFILE_Icon}
//                             source={IMAGEPATH.PROFILE_Icon} />
//                     </View>
//                     <View>
//                         <LinearGradient colors={['#4c669f', '#3b5998', '#192f6a']} style={styles.linearGradient}>
//                             <Progress.Bar progress={0.4} width={150} color={'transparent'} />

//                         </LinearGradient>
//                     </View>
//                 </View>
//             </ImageBackground>
//         </View>
//     )
// }

// export default ShoesSelector

// const styles = StyleSheet.create({
//     linearGradient: {
//       height:height*0.02,
//       width:width*0.20,
//         paddingLeft: 15,
//         paddingRight: 15,
//         borderRadius: 5,
//         borderColor:"black"
//       },
//     box: {
//         width: 300,
//         height: 30,
//         marginVertical: 20,
//         borderColor: '#000000',
//         borderWidth: 1,
//         borderRadius: 7.0,

//     },
//     PROFILE_Icon: {
//         height: height * 0.08,
//         width: width * 0.17,
//         resizeMode: 'contain'
//     },
//     ProfileVIew: {
//         height: height * 0.09,
//         width: width * 0.30,
//         alignSelf: 'center',
//         borderWidth: 2,
//     },
//     HeadingView: {
//         height: height * 0.12,
//         width: width * 0.90,
//         alignSelf: 'center',
//         borderWidth: 2,
//         borderColor: "#265335",
//         flexDirection: "row"
//     },
//     mainContainer: {
//         height: "100%",
//         width: "100%",
//         // justifyContent:'center'
//     },
//     ImageBackground: {
//         height: "100%",
//         width: "100%",
//         //justifyContent:'center'
//     },
//     fakeView: {
//         height: height * 0.06,
//         width: width * 0.95,
//         alignSelf: "center",
//     },
// })
