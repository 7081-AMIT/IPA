import {
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Image,
  View,
  ImageBackground,
} from "react-native";
import React, { useEffect, useState } from "react";
import { IMAGEPATH } from "../../Icon/Icon";

const { height, width } = Dimensions.get("window");
const Splash = (props) => {
  const [isVisible, setIsVisible] = useState(false);
  useEffect(() => {
    setTimeout(function () {
      // props.navigation.navigate("Gender");
      setIsVisible(true);
    }, 3000);
  }, []);

  return (
    <View style={styles.main}>
      <ImageBackground
        style={styles.backgroundStyles}
        source={IMAGEPATH.SPLASH_BACKGROUND}
      >
        <View style={styles.vw_image}>
          <TouchableOpacity
            onPress={() => props.navigation.navigate("Gender")}
          >
            <Image style={styles.logo} source={IMAGEPATH.SPLASH_LOGO} />
          </TouchableOpacity>
        </View>
      </ImageBackground>
    </View>
  );
};

export default Splash;

const styles = StyleSheet.create({
  backgroundStyles: {
    height: height * 1,
    width: width * 1,
  },
  main: {
    height: height * 1,
    width: width * 1,
  },
  vw_image: {
    height: height * 1,
    width: width * 1,

    justifyContent: "center",
    alignSelf: "center",
    alignItems: "center",
  },
  logo: {
    height: 110,
    width: 200,
  },
});
