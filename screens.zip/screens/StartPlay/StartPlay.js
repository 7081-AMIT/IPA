import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Modal,
  Image,
  ImageBackground,
  TouchableOpacity,
  TextInput,
  StatusBar,
  ScrollView,
  SafeAreaView,
} from "react-native";
import React, { useState } from "react";
import { IMAGEPATH } from "../../Icon/Icon";
//import { SafeAreaView } from "react-native-safe-area-context";
import LinearGradient from "react-native-linear-gradient";
const { height, width } = Dimensions.get("window");

import { ProgressBar, MD3Colors } from "react-native-paper";

import AppButton from "../../components/CustomButton/CustomButton";

const StartPlay = (props) => {
  return (
    <SafeAreaView>
      <ScrollView>
        <View style={styles.mainContainer}>
          <ImageBackground
            style={styles.ImageBackground}
            source={IMAGEPATH.SPLASH_BACKGROUND}
          >
            {/* headingView */}
            <View style={styles.headingView}>
              <View style={styles.backView}>
                <TouchableOpacity
                  onPress={() => props.navigation.navigate("ShareDetails")}
                >
                  <Image
                    style={styles.backImage}
                    source={IMAGEPATH.BACK_ICON}
                  />
                </TouchableOpacity>
              </View>

              <View style={styles.headingmidView}>
                <View style={styles.headingchildmidView}>
                  <View
                    style={{
                      height: height * 0.045,
                      width: width * 0.3,
                      // backgroundColor: "blue",
                      // marginLeft: width * 0.03,
                      // justifyContent: "space-around",
                      flexDirection: "row",
                    }}
                  >
                    <View style={styles.DollarImageView}>
                      <Image
                        style={{
                          height: height * 0.03,
                          width: width * 0.064,
                          resizeMode: "contain",
                        }}
                        source={IMAGEPATH.Dollar_white}
                      />
                    </View>
                    <View style={styles.TextView}>
                      <Text style={styles.BarTextStyle}>30/100</Text>
                    </View>
                  </View>
                  <View style={styles.progressbarView}>
                    <ProgressBar
                      progress={0.5}
                      color={"#77CFCF"}
                      style={{
                        height: height * 0.01,
                        width: width * 0.26,
                        borderWidth: 1,
                        borderColor: "#8EC6A9",
                        borderRadius: 10,
                        backgroundColor: "transparent",
                      }}
                    />
                  </View>
                </View>

                <View
                  style={{
                    height: height * 0.081,
                    width: width * 0.3,
                    //  backgroundColor: "red",
                    marginLeft: width * 0.01,
                    //justifyContent: "center",
                    // flexDirection: "row",
                  }}
                >
                  <View
                    style={{
                      height: height * 0.045,
                      width: width * 0.3,
                      // backgroundColor: "blue",
                      // marginLeft: width * 0.03,
                      // justifyContent: "space-evenly",
                      flexDirection: "row",
                    }}
                  >
                    <View style={styles.DollarImageView}>
                      <Image
                        style={{
                          height: height * 0.03,
                          width: width * 0.064,
                          resizeMode: "contain",
                        }}
                        source={IMAGEPATH.Dollar_white}
                      />
                    </View>
                    <View style={styles.TextView}>
                      <Text style={styles.BarTextStyle}>30/100</Text>
                    </View>
                  </View>
                  <View style={styles.progressbarView}>
                    <ProgressBar
                      progress={0.5}
                      color={"#77CFCF"}
                      style={{
                        height: height * 0.01,
                        width: width * 0.27,
                        borderWidth: 1,
                        borderColor: "#8EC6A9",
                        borderRadius: 10,
                        backgroundColor: "transparent",
                      }}
                    />
                  </View>
                </View>
                <View style={styles.ProfileView}>
                  <TouchableOpacity>
                    <Image
                      style={styles.ProfileImageStyle}
                      source={IMAGEPATH.PROFILE_Icon}
                    />
                  </TouchableOpacity>
                </View>
              </View>
            </View>
            <LinearGradient
              colors={[
                " rgba(255, 255, 255, 0.2)",
                " rgba(255, 255, 255, 0) ",
                // " rgba(0, 0, 0, 0.10)",
              ]}
              style={styles.secondView}
            >
              <View style={styles.secondChildView}>
                <View
                  style={{
                    height: height * 0.06,
                    width: width * 0.45,
                    //  backgroundColor: "green",
                    // marginLeft: width * 0.15,
                    justifyContent: "center",
                  }}
                >
                  <Text style={styles.HeadingTextStyle}>Umair Siddiqui</Text>
                </View>
                <View style={styles.settingView}>
                  <TouchableOpacity>
                    <Image
                      style={styles.SettingImage}
                      source={IMAGEPATH.Setting_Icon}
                    />
                  </TouchableOpacity>
                </View>
              </View>
              <View style={styles.secondChildView1}>
                <View
                  style={{
                    height: height * 0.06,
                    width: width * 0.1,
                    alignSelf: "center",
                    //backgroundColor: "green",
                    // marginLeft: width * 0.15,
                    justifyContent: "center",
                  }}
                >
                  <Text style={styles.ParagraphTextStyle}>Weight</Text>
                </View>
                <View
                  style={{
                    height: height * 0.055,
                    width: width * 0.22,
                    alignSelf: "center",
                    borderRadius: 30,
                    backgroundColor: "#3BD0C7",
                    // marginLeft: width * 0.15,
                    justifyContent: "center",
                  }}
                >
                  <Text style={styles.weightTextStyle}>65 KG</Text>
                </View>
                <View
                  style={{
                    height: height * 0.055,
                    width: width * 0.25,
                    alignSelf: "center",
                    // borderRadius: 30,
                    //backgroundColor: "#3BD0C7",
                    // marginLeft: width * 0.15,
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Text style={styles.ParagraphTextStyle1}>Male</Text>
                </View>
                <View
                  style={{
                    height: height * 0.06,
                    width: width * 0.1,
                    alignSelf: "center",
                    // backgroundColor: "green",
                    // marginLeft: width * 0.15,
                    justifyContent: "center",
                  }}
                >
                  <Text style={styles.ParagraphTextStyle}>Height</Text>
                </View>
                <View
                  style={{
                    height: height * 0.055,
                    width: width * 0.22,
                    alignSelf: "center",
                    borderRadius: 30,
                    backgroundColor: "#964BBA",
                    // marginLeft: width * 0.15,
                    justifyContent: "center",
                  }}
                >
                  <Text style={styles.weightTextStyle}>65.5 CM</Text>
                </View>
              </View>
            </LinearGradient>
            <View style={styles.humanView}>
              <Image
                style={styles.humanImageStyle}
                source={IMAGEPATH.MALE_ICON}
              />
            </View>
            <LinearGradient
              colors={[" rgba(255, 255, 255, 0.2)", " rgba(255, 255, 255, 0) "]}
              style={styles.ThirdView}
            >
              <View
                style={{
                  height: height * 0.15,
                  width: width * 0.82,
                  // borderColor: "white",
                  // alignItems: "center",
                  justifyContent: "space-between",
                  // backgroundColor: "green",
                  alignSelf: "center",
                  flexDirection: "row",
                }}
              >
                <View
                  style={{
                    height: height * 0.15,
                    width: width * 0.34,
                    // borderColor: "white",
                    // alignItems: "center",
                    // justifyContent: "center",
                    //backgroundColor: "blue",
                    alignSelf: "center",
                    //flexDirection: "row",
                  }}
                >
                  <View
                    style={{
                      height: height * 0.055,
                      width: width * 0.25,
                      alignSelf: "center",
                      // borderRadius: 30,
                      //backgroundColor: "#3BD0C7",
                      // marginLeft: width * 0.15,
                      // justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <Text style={styles.stepsTextStyle1}>0.00</Text>
                  </View>
                  <View
                    style={{
                      height: height * 0.055,
                      width: width * 0.3,
                      alignSelf: "center",
                      // borderRadius: 30,
                      //backgroundColor: "red",
                      // marginLeft: width * 0.15,
                      // justifyContent: "center",
                      // alignItems: "center",
                      flexDirection: "row",
                    }}
                  >
                    <View style={styles.LoactionView}>
                      <Image
                        style={{
                          resizeMode: "cover",
                          height: height * 0.03,
                          width: width * 0.06,
                          // backgroundColor: "green",
                          //   flex: 1,
                        }}
                        source={IMAGEPATH.Steps_Icon}
                      />
                    </View>
                    <Text style={styles.ParagraphTextStyle2}>Total Steps </Text>
                  </View>
                </View>

                <View
                  style={{
                    height: height * 0.15,
                    width: width * 0.39,
                    // borderColor: "white",
                    // alignItems: "center",
                    // justifyContent: "center",
                    // backgroundColor: "blue",
                    alignSelf: "center",
                    //flexDirection: "row",
                  }}
                >
                  <View
                    style={{
                      height: height * 0.055,
                      width: width * 0.25,
                      alignSelf: "center",
                      // borderRadius: 30,
                      //  backgroundColor: "blue",
                      // marginLeft: width * 0.15,
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <Text style={styles.stepsTextStyle1}>0.00</Text>
                  </View>
                  <View
                    style={{
                      height: height * 0.055,
                      width: width * 0.38,
                      alignSelf: "center",
                      // borderRadius: 30,
                      //backgroundColor: "red",
                      // marginLeft: width * 0.15,
                      // justifyContent: "center",
                      // alignItems: "center",
                      flexDirection: "row",
                    }}
                  >
                    <View style={styles.LoactionView}>
                      <Image
                        style={{
                          resizeMode: "cover",
                          height: height * 0.03,
                          width: width * 0.06,
                          // backgroundColor: "green",
                          //   flex: 1,
                        }}
                        source={IMAGEPATH.Run_Icon}
                      />
                    </View>
                    <Text style={styles.ParagraphTextStyle2}>
                      Total Kilometers
                    </Text>
                  </View>
                </View>
              </View>
            </LinearGradient>
            <View style={styles.button_vw}>
              <View style={styles.loginButtonVIew}>
                <AppButton
                  title="Let’s Start"
                  ButtonPress={() => props.navigation.navigate("PlayPop")}
                />
              </View>

              <View style={styles.TextLink}>
                <TouchableOpacity
                  onPress={() => props.navigation.navigate("Play")}
                >
                  <Text style={styles.textlinkstyle}>How to play?</Text>
                </TouchableOpacity>
              </View>
            </View>
          </ImageBackground>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default StartPlay;

const styles = StyleSheet.create({
  LoactionView: {
    height: height * 0.06,
    width: width * 0.08,
    // borderColor: "white",
    alignItems: "center",
    // justifyContent: "center",
    //backgroundColor: "green",
  },
  ThirdView: {
    height: height * 0.12,
    width: width * 0.98,
    // borderColor: "white",
    // alignItems: "center",
    // justifyContent: "center",
    // backgroundColor: "green",
    alignSelf: "center",
    // borderWidth: 1,
    // borderColor: "",
    // borderBottomColor: "#00000",
    borderBottomWidth: 0.2,
    shadowColor: "#000000",
    shadowOffset: { width: 0.9, height: 2.5 },
    shadowOpacity: 0.4,
    shadowRadius: 15,
    elevation: 0,
    backdropFilter: "blur",
  },
  humanImageStyle: {
    height: height * 0.7,
    width: width * 0.7,
    resizeMode: "contain",
  },
  humanView: {
    height: height * 0.35,
    width: width * 0.85,
    // borderColor: "white",
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor: "green",
    alignSelf: "center",
    // borderWidth: 1,
  },
  weightTextStyle: {
    fontSize: width * 0.042,
    color: "#FFFFFF",
    textAlign: "center",

    fontFamily: "Sen-Regular",
  },
  ParagraphTextStyle: {
    fontSize: width * 0.03,
    color: "#FFFFFF",
    // textAlign: "center",
    fontFamily: "SairaSemiCondensed-regular",
  },
  ParagraphTextStyle2: {
    fontSize: width * 0.035,
    color: "#FFFFFF",
    // textAlign: "center",
    fontFamily: "SairaSemiCondensed-regular",
  },
  ParagraphTextStyle1: {
    fontSize: width * 0.045,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-regular",
  },
  textlinkstyle: {
    fontSize: width * 0.045,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-regular",
  },
  stepsTextStyle1: {
    fontSize: width * 0.085,
    color: "#FFFFFF",
    textAlign: "center",
    fontFamily: "SairaSemiCondensed-regular",
  },
  HeadingTextStyle: {
    fontSize: width * 0.055,
    color: "#FFFFFF",
    //textAlign: "center",
    fontFamily: "SairaSemiCondensed-Bold",
  },
  secondChildView: {
    height: height * 0.075,
    width: width * 0.88,
    alignSelf: "center",
    // backgroundColor: "red",
    // marginLeft: width * 0.01,
    justifyContent: "space-between",
    flexDirection: "row",
  },
  secondChildView1: {
    height: height * 0.075,
    width: width * 0.92,
    alignSelf: "center",
    //backgroundColor: "red",
    marginLeft: width * 0.04,
    // justifyContent: "space-between",
    flexDirection: "row",
  },
  secondView: {
    height: height * 0.19,
    width: width * 0.98,
    // borderColor: "white",
    // alignItems: "center",
    // justifyContent: "center",
    // backgroundColor: "green",
    alignSelf: "center",
    // borderWidth: 1,
    borderColor: "#000000",
    // borderBottomColor: "#00000",
    borderBottomWidth: 0.18,
    shadowColor: "#000000",
    shadowOffset: { width: -15, height: 30 },
    shadowOpacity: 0,
    // shadowRadius: 15,
    // elevation: 0,
    backdropFilter: "blur",
  },
  ProfileImageStyle: {
    height: height * 0.062,
    width: width * 0.13,
    resizeMode: "contain",
  },
  ProfileView: {
    height: height * 0.07,
    width: width * 0.2,
    // borderColor: "white",
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor: "green",
    alignSelf: "center",
  },

  headingchildmidView: {
    height: height * 0.081,
    width: width * 0.3,
    //backgroundColor: "red",
    marginLeft: width * 0.01,
    //justifyContent: "center",
    // flexDirection: "row",
  },
  headingmidView: {
    height: height * 0.08,
    width: width * 0.65,
    // backgroundColor: "green",
    marginLeft: width * 0.01,
    //justifyContent: "center",
    flexDirection: "row",
  },
  progressbarView: {
    height: height * 0.02,
    width: width * 0.27,
    // backgroundColor: "yellow",
    // marginLeft: width * 0.01,
    justifyContent: "center",
    //flexDirection: "row",
  },
  backImage: {
    height: height * 0.02,
    width: width * 0.06,
    resizeMode: "contain",
  },
  SettingImage: {
    height: height * 0.04,
    width: width * 0.09,
    resizeMode: "contain",
  },

  headingView: {
    //backgroundColor: "blue",
    height: height * 0.13,
    width: width * 0.95,
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    //justifyContent: "space-",
  },
  box: {
    width: width * 0.3,
    height: height * 0.02,
    marginVertical: 20,
    borderColor: "white",
    borderWidth: 2,
    borderRadius: 20,
  },
  BarTextStyle: {
    fontSize: width * 0.045,
    color: "#FFFFFF",
    // textAlign: "center",
    fontFamily: "SairaSemiCondensed-Regular",
  },
  TextView: {
    height: height * 0.04,
    width: width * 0.18,
    // borderColor: "white",
    // alignItems: "center",
    justifyContent: "center",
    // backgroundColor: "green",
  },
  backView: {
    height: height * 0.04,
    width: width * 0.11,
    // borderColor: "white",
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor: "green",
  },
  settingView: {
    height: height * 0.06,
    width: width * 0.11,
    // borderColor: "white",
    // alignSelf: "center",
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor: "green",
  },
  DollarImageView: {
    height: height * 0.04,
    width: width * 0.075,
    // borderColor: "white",
    // alignItems: "center",
    justifyContent: "center",
    //  backgroundColor: "blue",
  },
  mainContainer: {
    height: height,
    width: width,
    // justifyContent:'center'
  },
  ImageBackground: {
    height: height,
    width: width,
    //justifyContent:'center'
  },
  loginButtonVIew: {
    height: height * 0.1,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
  },
  button_vw: {
    height: height * 0.25,
    width: width,
    justifyContent: "center",
    // alignItems: "center",
    /// backgroundColor: "red",
  },
  loginButtonVIew: {
    height: height * 0.11,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    // backgroundColor: "green",
  },

  TextLink: {
    height: height * 0.045,
    width: width * 0.9,
    alignSelf: "center",
    justifyContent: "center",
    marginBottom: height * 0.06,
    // backgroundColor: "green",
  },
});
